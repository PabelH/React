# Backend MERN - Calendar

Backend que creamos en mi curso de React: de cero a experto

fernando-herrera.com

## Importante
Recuerden cambiar las variables de entorno porque el URL de la base de datos lo paso cambiando constantemente y deben de usar una base de datos de la cual ustedes tengan acceso a ella.